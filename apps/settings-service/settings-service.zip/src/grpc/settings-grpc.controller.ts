import { Controller, UsePipes, ValidationPipe } from '@nestjs/common';
import { GrpcMethod } from '@nestjs/microservices';
import { Public, Roles } from '@nebula/grpc-auth';
import { SettingsService } from '../settings.service';
import { settings } from '@nebula/protos';

const Pipe = new ValidationPipe({
  whitelist: true,
  forbidNonWhitelisted: true,
  transform: true,
  transformOptions: { enableImplicitConversion: true },
});

@Controller()
@UsePipes(Pipe)
export class SettingsGrpcController {
  constructor(private readonly svc: SettingsService) {}

  @Public()
  @GrpcMethod('SettingsService', 'GetString')
  async getString(req: settings.GetReq): Promise<settings.GetStringRes> {
    const env = req.environment?.trim() ? req.environment : 'default';
    const { value, found } = await this.svc.getString(req.namespace, req.key, env);
    return { value: value ?? '', found };
  }

  @Roles('admin')
  @GrpcMethod('SettingsService', 'SetString')
  async setString(req: settings.SetStringReq): Promise<settings.SetStringRes> {
    const env = req.environment?.trim() ? req.environment : 'default';
    const value = await this.svc.setString(req.namespace, req.key, req.value, env);
    return { value };
  }

  @Roles('admin')
  @GrpcMethod('SettingsService', 'DeleteString')
  async deleteString(req: settings.DeleteReq): Promise<settings.DeleteRes> {
    const env = req.environment?.trim() ? req.environment : 'default';
    const deleted = await this.svc.deleteString(req.namespace, req.key, env);
    return { deleted };
  }
}
